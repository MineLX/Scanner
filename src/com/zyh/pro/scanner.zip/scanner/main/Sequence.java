package com.zyh.pro.scanner.main;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Sequence<E> {
	void consume(CallBack<E> consumer);

	void consumeAll(CallBack<E> consumer);

	List<E> map(Function<List<E>, E> converter, Predicate<E> terminatorPredicate);

	List<E> toList();

	List<E> til(E endToken);

	interface CallBack<ELEMENT> {
		void onElementComes(ELEMENT element, int startAt);

		default void onEnd() {
		}
	}
}
