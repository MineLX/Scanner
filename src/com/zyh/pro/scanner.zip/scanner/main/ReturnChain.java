package com.zyh.pro.scanner.main;

import java.util.ArrayList;
import java.util.List;

public abstract class ReturnChain<RETURN, CLUE> {

	private final List<ReturnChain<RETURN, CLUE>> children;

	private ReturnChain<RETURN, CLUE> next;

	public ReturnChain() {
		children = new ArrayList<>();
	}

	public RETURN get(CLUE clue) {
		if (isConsumable(clue))
			return onConsume(clue);
		if (next != null)
			return next.get(clue);
		return null;
	}

	protected abstract boolean isConsumable(CLUE clue);

	protected abstract RETURN onConsume(CLUE clue);

	public static class Builder<RETURN, CLUE> {
		private ReturnChain<RETURN, CLUE> result;

		private ReturnChain<RETURN, CLUE> current;

		public Builder<RETURN, CLUE> next(ReturnChain<RETURN, CLUE> next) {
			if (result == null) {
				result = current = next;
				return this;
			}
			current.next = next;
			current = next;
			return this;
		}

		public ReturnChain<RETURN, CLUE> build() {
			return result;
		}
	}
}
