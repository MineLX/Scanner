package com.zyh.pro.scanner.main;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class Tokenizer implements Iterator<String>, Sequence<String> {

	private final IndexedIterator<String> iterator;

	public Tokenizer(IndexedIterator<String> iterator) {
		this.iterator = iterator;
	}

	@Override
	public void consume(CallBack<String> consumer) {
		pushNext(consumer);
		if (!iterator.hasNext())
			consumer.onEnd();
	}

	private void pushNext(CallBack<String> consumer) {
		int index = iterator.getIndex();
		consumer.onElementComes(next(), index);
	}

	@Override
	public String next() {
		return iterator.next();
	}

	@Override
	public boolean hasNext() {
		return iterator.hasNext();
	}

	@Override
	public List<String> toList() {
		List<String> result = new LinkedList<>();
		consumeAll((element, startAt) -> result.add(element));
		return result;
	}

	@Override
	public List<String> map(Function<List<String>, String> converter, Predicate<String> terminatorPredicate) {
		List<String> result = new ArrayList<>();
		consumeAll(new FunctionalCombiner(combination -> result.add(converter.apply(combination)), terminatorPredicate));
		return result;
	}

	@Override
	public void consumeAll(CallBack<String> consumer) {
		while (hasNext())
			pushNext(consumer);
		consumer.onEnd();
	}

	@Override
	public List<String> til(String endToken) {
		List<String> result = new ArrayList<>();
		while (hasNext()) {
			String next = next();
			if (next.equals(endToken))
				break;
			result.add(next);
		}
		return result;
	}

}
