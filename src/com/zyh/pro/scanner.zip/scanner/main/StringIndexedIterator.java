package com.zyh.pro.scanner.main;

public class StringIndexedIterator implements IndexedIterator<String> {

	private final ToResult<String, IStringScanner> matcherToResult;

	private final IStringScanner stringScanner;

	public StringIndexedIterator(IStringScanner stringScanner, ToResult<String, IStringScanner> matcherToResult) {
		this.matcherToResult = matcherToResult;
		this.stringScanner = stringScanner;
	}

	@Override
	public boolean hasNext() {
		return stringScanner.hasNext();
	}

	@Override
	public String next() {
		return matcherToResult.get(stringScanner);
	}

	@Override
	public int getIndex() {
		return stringScanner.getIndex();
	}
}
