package com.zyh.pro.scanner.main;

import java.util.Iterator;

public interface IndexedIterator<E> extends Iterator<E> {
	int getIndex();
}
