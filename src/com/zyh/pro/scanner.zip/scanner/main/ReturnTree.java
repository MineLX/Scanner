package com.zyh.pro.scanner.main;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static java.lang.String.valueOf;

public class ReturnTree<ELEMENT, CLUE> {

	private final List<ReturnTree<ELEMENT, CLUE>> children;

	private final Matcher<CLUE> matcher;

	private final ELEMENT leafElement;

	public ReturnTree(ELEMENT leafElement, Matcher<CLUE> matcher) {
		this.matcher = matcher;
		this.leafElement = leafElement;
		children = new ArrayList<>();
	}

	public ELEMENT search(CLUE clue) {
		if (!matcher.isMatched(clue))
			return null;

		matcher.onMatched(clue);

		ELEMENT self = leafElement;
		if (self != null) // this is a leaf
			return self;

		for (ReturnTree<ELEMENT, CLUE> child : children) {
			ELEMENT childSearchResult = child.search(clue);
			if (childSearchResult != null)
				return childSearchResult;
		}
		return null;
	}

	public void addChild(ReturnTree<ELEMENT, CLUE> child) {
		children.add(child);
	}

	@Override
	public String toString() {
		String childrenAsText = children.stream().map(ReturnTree::toString)
				.collect(Collectors.joining(", "));
		if (children.size() == 0)
			childrenAsText = valueOf(leafElement);
		return "SearchTree(" +
				childrenAsText +
				")";
	}

	// FIXME 2020/4/27  wait for me!!!  move to Tree(Unmodifiable)
	public static class Builder<ELEMENT, CLUE> {

		private final ReturnTree<ELEMENT, CLUE> root;

		public Builder(Matcher<CLUE> matcher) {
			root = new ReturnTree<>(null, matcher);
		}

		public Path path(Matcher<CLUE> matcher) {
			ReturnTree<ELEMENT, CLUE> newTreePath = new ReturnTree<>(null, matcher);
			root.addChild(newTreePath);
			return new Path(newTreePath);
		}

		public Builder<ELEMENT, CLUE> end(ELEMENT leafValue, Matcher<CLUE> matcher) {
			root.addChild(new ReturnTree<>(leafValue, matcher));
			return this;
		}

		public ReturnTree<ELEMENT, CLUE> build() {
			return root;
		}

		public class Path {
			private ReturnTree<ELEMENT, CLUE> currentTree;

			private Path(ReturnTree<ELEMENT, CLUE> currentTree) {
				this.currentTree = currentTree;
			}

			public Path path(Matcher<CLUE> pathMatcher) {
				ReturnTree<ELEMENT, CLUE> nextPath = new ReturnTree<>(null, pathMatcher);
				currentTree.addChild(nextPath);
				return new Path(nextPath);
			}

			public Builder<ELEMENT, CLUE> end(ELEMENT leafValue, Matcher<CLUE> endPathMatcher) {
				currentTree.addChild(new ReturnTree<>(leafValue, endPathMatcher));
				return Builder.this;
			}
		}
	}
}
