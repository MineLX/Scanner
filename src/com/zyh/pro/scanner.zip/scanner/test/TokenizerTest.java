package com.zyh.pro.scanner.test;

import com.zyh.pro.scanner.main.*;
import com.zyh.pro.taskscheduler.main.CallbackTask;
import org.junit.Test;

import java.util.List;

import static java.lang.String.valueOf;
import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

public class TokenizerTest {
	@Test
	public void til() {
		IStringScanner source = new StringScanner("print()");
		Tokenizer tokenizer = getTokenizer(source);
		assertThat(tokenizer.til("(").toString(), is("[p, r, i, n, t]"));
	}

	@Test
	public void edge_toList() {
		IStringScanner source = new TrimmedStringScanner(new StringScanner("1 "));
		Tokenizer tokenizer = getTokenizer(source);
		assertThat(tokenizer.toList().toString(), is("[1]"));
	}

	@Test
	public void step_tokenizer() throws InterruptedException {
		CallbackTask task = new CallbackTask();
		Tokenizer tokenizer = getTokenizer(new StringScanner("hello"));
		assertThat(tokenizer.next(), is("h"));
		assertThat(tokenizer.next(), is("e"));
		assertThat(tokenizer.next(), is("l"));
		assertThat(tokenizer.next(), is("l"));
		tokenizer.consume(new Tokenizer.CallBack<String>() {
			@Override
			public void onElementComes(String element, int startAt) {
			}

			@Override
			public void onEnd() {
				task.done();
			}
		});
		assertThat(tokenizer.hasNext(), is(false));
		task.waitForCompletion();
	}

	@Test
	public void onEnd() {
		IStringScanner source = new StringScanner("hello");
		Tokenizer tokenizer = getTokenizer(source);
		Sequence.CallBack<String> callback = new Sequence.CallBack<String>() {
			boolean isEnd;

			@Override
			public void onElementComes(String element, int startAt) {
				System.out.println("hello");
			}

			@Override
			public void onEnd() {
				assertFalse(isEnd);
				isEnd = true;
			}
		};
		tokenizer.consume(callback);
		tokenizer.consume(callback);
	}

	@Test
	public void collector() {
		IStringScanner source = new StringScanner("print(456);print(123)");
		Tokenizer tokenizer = getTokenizer(source);
		List<String> result = tokenizer.map(tokens -> String.join("", tokens), token -> token.equals(";"));
		assertThat(result.toString(), is("[print(456);, print(123)]"));
	}

	@Test
	public void toList() {
		IStringScanner source = new StringScanner("hello");
		Tokenizer tokenizer = getTokenizer(source);
		List<String> result = tokenizer.toList();
		assertThat(result.toString(), is("[h, e, l, l, o]"));
	}

	@Test
	public void simple_test() {
		IStringScanner source = new StringScanner("hello");
		Tokenizer tokenizer = getTokenizer(source);
		tokenizer.consume(new TestTokenConsumer(asList(
				"h" + "0",
				"e" + "1",
				"l" + "2",
				"l" + "3",
				"o" + "4"
		)));
	}

	private static class TestTokenConsumer implements Tokenizer.CallBack<String> {

		private final List<String> result;

		private int index;

		private TestTokenConsumer(List<String> result) {
			this.result = result;
		}

		@Override
		public void onElementComes(String element, int startAt) {
			assertThat(element + startAt, is(result.get(index++)));
		}
	}

	private Tokenizer getTokenizer(IStringScanner scanner) {
		StringIndexedIterator iterator = new StringIndexedIterator(scanner,
				scanner1 -> valueOf(scanner1.nextChar()));
		return new Tokenizer(iterator);
	}
}
