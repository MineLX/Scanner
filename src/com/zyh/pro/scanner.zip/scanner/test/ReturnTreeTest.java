package com.zyh.pro.scanner.test;

import com.zyh.pro.scanner.main.IScanner;
import com.zyh.pro.scanner.main.Matcher;
import com.zyh.pro.scanner.main.ReturnTree;
import org.junit.Test;

import static com.zyh.pro.scanner.main.Matcher.functional;

public class ReturnTreeTest {
//	@Test
//	public void simple_test() {
//		ReturnTree.Builder<String, IScanner> builder = new ReturnTree.Builder<>(functional());
//	}
}
