package com.zyh.pro.scanner.test;

import com.zyh.pro.scanner.main.IScanner;
import com.zyh.pro.scanner.main.ReturnChain;
import com.zyh.pro.scanner.main.ReturnTree;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class ReturnChainTest {
	@Test
	public void children() {
		ReturnChain<String, IScanner> chain = new ReturnChain<String, IScanner>() {
			@Override
			protected boolean isConsumable(IScanner scanner) {
				return scanner.existsIf(Character::isAlphabetic);
			}

			@Override
			protected boolean isContinue() {

			}

			@Override
			protected String onConsume(IScanner scanner) {
				return null;
			}
		};
	}

	@Test
	public void simple_test() {
		ReturnChain.Builder<String, String> builder = new ReturnChain.Builder<>();
		ReturnChain<String, String> chain = builder.next(new ReturnChain<String, String>() {
			@Override
			protected String onConsume(String s) {
				return "world";
			}

			@Override
			protected boolean isConsumable(String s) {
				return s.equals("hello");
			}
		}).build();
		assertThat(chain.get("hello"), is("world"));
		assertNull(chain.get("?"));
	}
}
